from memory import Memory

# Your implementations of the classes below should not
# include any additional print statements.


class CyclicCache(Memory):
    def name(self):
        return "Cyclic"

    # Edit the code below to provide an implementation of a cache that
    # uses a cyclic caching strategy with a cache size of 4. You can
    # use additional methods and variables as you see fit as long as you
    # provide a suitable overridding of the lookup method.

    def __init__(self):
        super().__init__()
        self.cyclicCache = [(None, None), (None, None),
                            (None, None), (None, None)]
        self.count = 1

    def lookup(self, Address):
        ACache = [val[0] for val in self.cyclicCache]
        if Address not in ACache:
            # if address not in cache it gets added
            DCache = [val[1] for val in self.cyclicCache]
            data = (Address, super().lookup(Address))
            self.cyclicCache[self.count - 1] = data
            if self.count <= 3:
                self.count = self.count + 1
            else:
                self.count = 1
            ACache = [val[0] for val in self.cyclicCache]
            DCache = [val[1] for val in self.cyclicCache]
        DCache = [val[1] for val in self.cyclicCache]
        return DCache[ACache.index(Address)]


class LRUCache(Memory):
    def name(self):
        return "LRU"

    # Edit the code below to provide an implementation of a cache that
    # uses a least recently used caching strategy with a cache size of
    # 4. You can use additional methods and variables as you see fit as
    # long as you provide a suitable overridding of the lookup method.

    def __init__(self):
        super().__init__()
        self.lruCache = [(None, None), (None, None),
                         (None, None), (None, None)]

    def lookup(self, Address):
        ACache = [val[0] for val in self.lruCache]
        if Address in ACache:
            pointer = ACache.index(Address)
            DCache = [val[1] for val in self.lruCache]
            c = self.lruCache
            self.lruCache = c[0:pointer] + c[pointer+1:4]
            self.lruCache.append((Address, DCache[pointer]))
        else:
            ACache = [val[0] for val in self.lruCache]
            DCache = [val[1] for val in self.lruCache]
            self.lruCache = self.lruCache[1:4]
            data = Address, super().lookup(Address)
            self.lruCache.append(data)
            ACache = [val[0] for val in self.lruCache]
            DCache = [val[1] for val in self.lruCache]
        return DCache[ACache.index(Address)]
