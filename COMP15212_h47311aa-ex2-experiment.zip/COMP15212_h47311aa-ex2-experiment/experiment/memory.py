import queue
import hashlib
from random import randrange
# Various implementations of caching. This file has stub implementations.

class Memory:
    '''Basic lookup'''
    def __init__(self):
        self.hit_count = 0

    def get_hit_count(self):
        return self.hit_count

    def name(self):
        return "Memory"

    def lookup(self, address):
        # This one actually has no cache, so every lookup requires a
        # memory hit.
        self.hit_count += 1
        string = str(address ^ 3).encode()
        return hashlib.md5(string).hexdigest()[:8]

class CyclicCache(Memory):
    def name(self):
        return "Cyclic"

    # Edit the code below to provide an implementation of a cache that
    # uses a cyclic caching strategy with a cache size of 4. You can
    # use additional methods and variables as you see fit as long as you
    # provide a suitable overridding of the lookup method.

    def __init__(self):
        super().__init__()
        self.cyclicCache = [(None, None), (None, None),
                            (None, None), (None, None)]
        self.count = 1

    def lookup(self, Address):
        ACache = [val[0] for val in self.cyclicCache]
        if Address not in ACache:
            # if address not in cache it gets added
            DCache = [val[1] for val in self.cyclicCache]
            data = (Address, super().lookup(Address))
            self.cyclicCache[self.count - 1] = data
            if self.count <= 3:
                self.count = self.count + 1
            else:
                self.count = 1
            ACache = [val[0] for val in self.cyclicCache]
            DCache = [val[1] for val in self.cyclicCache]
        DCache = [val[1] for val in self.cyclicCache]
        return DCache[ACache.index(Address)]


class LRUCache(Memory):
    def name(self):
        return "LRU"

    # Edit the code below to provide an implementation of a cache that
    # uses a least recently used caching strategy with a cache size of
    # 4. You can use additional methods and variables as you see fit as
    # long as you provide a suitable overridding of the lookup method.

    def __init__(self):
        super().__init__()
        self.lruCache = [(None, None), (None, None),
                         (None, None), (None, None)]

    def lookup(self, Address):
        ACache = [val[0] for val in self.lruCache]
        if Address in ACache:
            pointer = ACache.index(Address)
            DCache = [val[1] for val in self.lruCache]
            c = self.lruCache
            self.lruCache = c[0:pointer] + c[pointer+1:4]
            self.lruCache.append((Address, DCache[pointer]))
        else:
            ACache = [val[0] for val in self.lruCache]
            DCache = [val[1] for val in self.lruCache]
            self.lruCache = self.lruCache[1:4]
            data = Address, super().lookup(Address)
            self.lruCache.append(data)
            ACache = [val[0] for val in self.lruCache]
            DCache = [val[1] for val in self.lruCache]
        return DCache[ACache.index(Address)]


class RandomCache(Memory):
    def __init__(self, size=4):
        super().__init__()

        # The cache.
        self.cache = {}
        # The cache size.
        self.cache_size = size
        # A list of keys that are in the cache. This will be used to work out
        # which slot to evict.
        self.cached_keys = []

    def name(self):
        return "Random"

    '''If the value is in the cache, get it and return it. Otherwise,
    get the value from memory and return it'''
    def lookup(self, address):
        # Is it in the cache? If so, return
        if address in self.cache:
            # mark the address as being the most recently used, i.e. send
            # to end of list
            self.cached_keys.remove(address)
            self.cached_keys.append(address)
            return self.cache[address]
        else:
            # Is the Cache full?
            if len(self.cached_keys) >= self.cache_size:
                # Grab a random key
                evictee = randrange(0, self.cache_size)
                removal = self.cached_keys[evictee]
                # Remove it from the list of cached keys.
                self.cached_keys.remove(removal)
                # Evict from the cache
                del self.cache[removal]
            # There should be a free space now.
            value = super().lookup(address)
            # Cache the value and push the key onto the queue.
            self.cache[address] = value
            # add to the list, thus marking the address as being the most
            # recently used
            self.cached_keys.append(address)
            return value