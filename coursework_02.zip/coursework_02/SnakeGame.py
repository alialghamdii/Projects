# My Snake Game!
# Screen Resolution used 1440x900
from tkinter import *
import tkinter.messagebox
from random import randint as rand
import random
import sys
import tkinter.messagebox
import csv
import pickle
import time
import os

# Game functions
# Saves usernames and score


def gameoverfunc():
    global gameOver, FirstPlay, NamePlayer
    ABC = ["A", "B", "C"]
    CheckFile = os.path.isfile("leaderboard.txt")
    if CheckFile is False:
        for i in range(3):
            with open("leaderboard.txt", "a+") as file1:
                file1.seek(0)
                data1 = file1.read(100)
                if len(data1) > 0:
                    file1.write("\n")
                file1.write(ABC[i] + ',' + '')
                file1.write("0")
    with open("leaderboard.txt", "a+") as file1:
        file1.seek(0)
        data1 = file1.read(100)
        if len(data1) > 0:
            file1.write("\n")
        file1.write(PlayerName + ',' + '')
    gameOver = True
    canvas.create_text(
        width / 2, height / 2, fill="white", font="Times 40 italic bold",
        text="GAME OVER!", underline=1)
    answer2 = tkinter.messagebox.askquestion(
        'Question 1', 'GAME OVER!\nWould you like to play again?')
    if answer2 == 'yes':
        a = open("leaderboard.txt", "a")
        a.write(str(score))
        a.close()
        window.destroy()
        startgame()
    if answer2 == 'no':
        a = open("leaderboard.txt", "a")
        a.write(str(score))
        a.close()
        window.destroy()
        window2.deiconify()
        FirstPlay = False
    leaderboardaftersorted()

# if game is saved, it gets saved to external files


def savegamefunc():
    global snake, positions, direction, score, currentlevel, sHeadPos
    global foodX, foodY, window, canvas, PlayerName, GameReady, GameisResumed
    if GameisResumed:
        GamePause()
    pickle.dump(PlayerName, open("namesaved.dat", "wb"))
    pickle.dump(snake, open("snakesaved.dat", "wb"))
    pickle.dump(positions, open("positionsaved.dat", "wb"))
    pickle.dump(direction, open("directionsaved.dat", "wb"))
    pickle.dump(score, open("scoresaved.dat", "wb"))
    pickle.dump(currentlevel, open("levelsaved.dat", "wb"))
    pickle.dump(sHeadPos, open("headPossaved.dat", "wb"))
    pickle.dump(foodX, open("foodXsaved.dat", "wb"))
    pickle.dump(foodY, open("foodYsaved.dat", "wb"))
    tkinter.messagebox.showinfo("saved", "Your Game Has Been Saved")

# Loads all variables from the saved files


def loadgamefunc():
    global Snakesaved, Positionsaved, Directionsaved
    global Scoresaved, Currentlevelsaved, canvas, Namesaved
    global txt, window, GameReady, HeadPossaved, FoodXsaved, FoodYsaved
    window.destroy()
    GameReady = True
    Snakesaved = pickle.load(open("snakesaved.dat", "rb"))
    Namesaved = pickle.load(open("namesaved.dat", "rb"))
    Positionsaved = pickle.load(open("positionsaved.dat", "rb"))
    Directionsaved = pickle.load(open("directionsaved.dat", "rb"))
    Scoresaved = pickle.load(open("scoresaved.dat", "rb"))
    Currentlevelsaved = pickle.load(open("levelsaved.dat", "rb"))
    HeadPossaved = pickle.load(open("headPossaved.dat", "rb"))
    FoodXsaved = pickle.load(open("foodXsaved.dat", "rb"))
    FoodYsaved = pickle.load(open("foodYsaved.dat", "rb"))
    startgame()

# this function sorts the scores from high to low


def leaderboardaftersorted():
    global file, file2, NameEntry, score, data, data2, slist, r_csv
    file = open("leaderboard.txt")
    r_csv = csv.reader(file)
    slist = sorted(r_csv, key=lambda row: int(row[1]), reverse=True)
    print(slist)
    file.close()
    file2 = open("leaderboardsorted.txt", "w+")
    Positioncounter = 0
    for i in range(len(slist)):
        firstline = slist[i][0] + "'s Score: " + slist[i][1]
        file2.seek(Positioncounter)
        currentlineLength = len(firstline)
        Positioncounter = Positioncounter + currentlineLength + 1
        print(firstline)
        file2.write(str(firstline))
        if i < len(slist) - 1:
            file2.write("\n")

# Cheat code to add points to game


def cheat(event):
    global score, txt
    score += 10
    txt = "SCORE:" + str(score)
    ScoreVar.set(txt)

# Displays names in the sorted files to the leaderboard


def leaderboard():

    global window4, canvas4, frame2, users, button13
    global file, name, score, sorted_list, txt6
    window4 = Toplevel()
    window4.title('Leaderboard')
    window4.config(bg='grey')
    window4.resizable(False, False)
    canvas4 = Canvas(window4, width=width, height=height)
    canvas4.create_image(width / 2, height / 2, anchor=CENTER,
                         image=textureimage, tag='texture')
    canvas4.place(x=0, y=0)
    window4 = setWindowDimension4(width, height)
    fileW = open('leaderboardsorted.txt')
    txt7 = fileW.readline()
    for i in range(2):
        txt6 = fileW.readline()
        txt7 = txt7 + "\n" + str(txt6)

    scorelabel2 = Label(canvas4, text='TOP  PLAYERS: ', fg='black',
                        highlightbackground='grey', font="Arcade 30 bold",
                        bg='grey')
    scorelabel2.place(x=165, y=100)

    scorelabel4 = Label(canvas4, text='-LEADERBAORD-', fg='black',
                        highlightbackground='grey', font="Arcade 35 bold",
                        bg='grey')
    scorelabel4.place(x=145, y=40)

    scorelabel6 = Label(canvas4, text=txt7, fg='black',
                        highlightbackground='grey', font="Arcade 30 bold",
                        bg='grey')
    scorelabel6.place(x=180, y=220)

    button13 = Button(canvas4, text='MAIN MENU', relief=FLAT, height=2,
                      width=10, highlightbackground='black',
                      command=closewindow4)
    button13.place(x=225, y=480)

    window4.mainloop()

# if game was paused then resumed, this shows a countdown
# that indicates the starting of the game again


def resuminggame():

    canvas.delete('pausing')
    canvas.delete('labelpause')
    canvas.update()
    canvas.create_text(280, 200, text='GAME RESUMING IN:',
                       font='Arcade 35 bold', fill='red', tag='labelresume')
    canvas.create_text(280, 300, text='3', font='Arcade 35 bold',
                       fill='red', tag='n3')
    canvas.update()
    time.sleep(1)
    canvas.delete('n3')
    canvas.update()
    canvas.create_text(280, 300, text='2', font='Arcade 35 bold',
                       fill='red', tag='n2')
    canvas.update()
    time.sleep(1)
    canvas.delete('n2')
    canvas.update()
    canvas.create_text(280, 300, text='1', font='Arcade 35 bold',
                       fill='red', tag='n1')
    canvas.update()
    time.sleep(1)
    canvas.delete('n1')
    canvas.delete('labelresume')
    canvas.update()

# BossKey gets activated when hitting the 'p' key and pauses the game is
# resumed.


def bosskey(event):
    global GameisResumed, bosskey, canvas6
    bosskey = Toplevel()
    bosskey.title('Excel Sheet - Work')
    bosskey.resizable(False, False)
    canvas6 = Canvas(bosskey, width=1920, height=1080)
    canvas6.pack()
    bosskeyimage = PhotoImage(file='BossKey.png')
    canvas6.create_image(960, 540, anchor=CENTER,
                         image=bosskeyimage, tag='bosskey')
    if GameisResumed:
        pausegame()
    else:
        window.after(120, moveSnake)

    bosskey.mainloop()

# When game is paused and returned to main menu
# this function takes the player back to the game
# when hitting the CONTINUE button on main menu


def PreviousRun():
    global FirstPlay

    if FirstPlay is False:

        if GameisResumed is False:
            window.deiconify()
            window2.withdraw()
        else:
            tkinter.messagebox.showinfo(
                "error1", "No Game is currently being run")
    else:
        tkinter.messagebox.showinfo("error2", "No Game is Currently being run")


# When returning to Main menu, this function hides the game until going back in
def GoToMainMenu():
    global GameisResumed, FirstPlay, window, window2
    if GameisResumed is True:

        window.withdraw()
        window2.deiconify()
        FirstPlay = False
        pausegame()
    else:
        window.withdraw()
        window2.deiconify()
        FirstPlay = False

# for restarting the game when game is over


def StartFresh():
    global FirstPlay, PlayerName
    if FirstPlay is False:
        window.destroy()
        startgame()
    else:
        startgame()

# customizing the control function 1


def controlcustomization():
    global windowCB, LeftButton, RightButton, textABC
    global UpButton, DownButton, TopCB, canvas, textABC2
    TopCB = Toplevel()
    TopCB.resizable(False, False)
    TopCB.title("Control Customization")
    TopCB.geometry("400x400")

    textABC = "Note: You May Only Input Lowercase Alphabets."
    UpdateCompletedLabel = Label(TopCB, text=textABC,
                                 fg="red", font="Arcade 8 bold")
    UpdateCompletedLabel.place(x=85, y=340)

    UpdateCompletedLabel2 = Label(TopCB, text="Hint: 'P' key is your bosskey.",
                                  fg="red", font="Arcade 8 bold")
    UpdateCompletedLabel2.place(x=125, y=360)

    textABC2 = "CHEAT: add 10 points to your score by hitting the'O' key."
    UpdateCompletedLabel3 = Label(TopCB, text=textABC2,
                                  fg="red", font="Arcade 8 bold")
    UpdateCompletedLabel3.place(x=70, y=380)

    LeftButton = Entry(TopCB)
    RightButton = Entry(TopCB)
    UpButton = Entry(TopCB)
    DownButton = Entry(TopCB)

    EntryLabel = Label(TopCB,
                       text="Enter Your prefered Controls\n with alphabets: ",
                       font="Acade 16 bold")
    LeftEntryLabel = Label(TopCB, text="Left: ", font="Arial 12")
    RightEntryLabel = Label(TopCB, text="Right: ", font="Arial 12")
    UpEntryLabel = Label(TopCB, text="Up: ", font="Arial 12")
    DownEntryLabel = Label(TopCB, text="Down: ", font="Arial 12")

    EntryLabel.place(x=65, y=20)
    LeftEntryLabel.place(x=30, y=100)
    RightEntryLabel.place(x=30, y=150)
    UpEntryLabel.place(x=30, y=200)
    DownEntryLabel.place(x=30, y=250)

    LeftButton.place(x=100, y=100)
    RightButton.place(x=100, y=150)
    UpButton.place(x=100, y=200)
    DownButton.place(x=100, y=250)

    UpdateControlsButton = Button(
        TopCB,
        text="Update Controls",
        command=updatecontrol)
    UpdateControlsButton.place(x=120, y=280)
    UpdateControlsButton2 = Button(TopCB, text="Back", command=TopCBdestroy)
    UpdateControlsButton2.place(x=160, y=315)

# customizing the control function 2, which unbinds previous settings and
# bind new buttons


def updatecontrol():
    global direction, LeftButtonEntry, RightButtonEntry, UpButtonEntry
    global DownButtonEntry, InvalidInputLabel1, USInputLabel1, TopCB, canvas

    InvalidInputLabel1 = Label(TopCB, text="(Invalid Input!)",
                               fg="red", font="Times 10 italic bold")
    InvalidInputLabel2 = Label(TopCB, text="(Invalid Input!)",
                               fg="red", font="Times 10 italic bold")
    InvalidInputLabel3 = Label(TopCB, text="(Invalid Input!)",
                               fg="red", font="Times 10 italic bold")
    InvalidInputLabel4 = Label(TopCB, text="(Invalid Input!)",
                               fg="red", font="Times 10 italic bold")
    USInputLabel1 = Label(TopCB, text="Control Updated!",
                          fg="green", font="Times 9 italic bold")
    USInputLabel2 = Label(TopCB, text="Control Updated!",
                          fg="green", font="Times 9 italic bold")
    USInputLabel3 = Label(TopCB, text="Control Updated!",
                          fg="green", font="Times 9 italic bold")
    USInputLabel4 = Label(TopCB, text="Control Updated!",
                          fg="green", font="Times 9 italic bold")

    Alphabets = [
        "a",
        "b",
        "c",
        "d",
        "e",
        "f",
        "g",
        "h",
        "i",
        "j",
        "k",
        "l",
        "m",
        "n",
        "o",
        "p",
        "q",
        "r",
        "s",
        "t",
        "u",
        "v",
        "w",
        "x",
        "y",
        "z"]

    if LeftButton.get() in Alphabets:
        L = "<" + LeftButton.get() + ">"
        canvas.unbind("<Left>")
        canvas.bind(L, leftKey)
        USInputLabel1.place(x=280, y=100)

    else:
        InvalidInputLabel1.place(x=280, y=100)

    if RightButton.get() in Alphabets:
        R = "<" + RightButton.get() + ">"
        canvas.unbind("<Right>")
        canvas.bind(R, rightKey)
        USInputLabel2.place(x=280, y=150)

    else:
        InvalidInputLabel2.place(x=280, y=150)

    if UpButton.get() in Alphabets:
        U = "<" + UpButton.get() + ">"
        canvas.unbind("<Up>")
        canvas.bind(U, upKey)
        USInputLabel3.place(x=280, y=200)

    else:
        InvalidInputLabel3.place(x=280, y=200)

    if DownButton.get() in Alphabets:
        D = "<" + DownButton.get() + ">"
        canvas.unbind("<Down>")
        canvas.bind(D, downKey)
        USInputLabel4.place(x=280, y=250)

    else:
        InvalidInputLabel4.place(x=280, y=250)


def TopCBdestroy():
    TopCB.destroy()


# Simulates a loading screen when starting the program
def loadingscreen():
    global width, height, window5, canvas5
    window5 = Tk()
    window5.config(bg='black')
    loadingimage = PhotoImage(file='snake.png')
    window5.resizable(False, False)
    window5.title('Loading ... ')
    width = 550
    height = 550
    canvas5 = Canvas(window5, width=width, height=height, bg='black')
    canvas5.pack()
    canvas5.create_image(
        270,
        225,
        anchor=CENTER,
        image=loadingimage,
        tag='loading')
    label2 = Label(window5, text='L  O  A  D  I  N  G . . .', fg='white',
                   font='Arcade 40 bold', bg='black')
    label2.place(x=width / 2, y=450, anchor=CENTER)
    window5 = setWindowDimension2(width, height)
    window5.after(200, closewindow)

    window5.mainloop()

# Simulates a loading screen when entering the game


def loadingscreen2():
    global width, height, window10, canvas10
    window10 = Toplevel()
    window10.config(bg='black')
    loadingimage = PhotoImage(file='snake.png')
    window10.resizable(False, False)
    window10.title('Loading ... ')
    width = 550
    height = 550
    canvas10 = Canvas(window10, width=width, height=height, bg='black')
    canvas10.pack()
    canvas10.create_image(
        270,
        225,
        anchor=CENTER,
        image=loadingimage,
        tag='loading')
    label2 = Label(canvas10, text='L  O  A  D  I  N  G . . .',
                   fg='white', font='Arcade 40 bold', bg='black')
    label2.place(x=width / 2, y=450, anchor=CENTER)
    window10 = setWindowDimension3(width, height)
    window10.after(200, closewindow2)

    window5.mainloop()

# Pauses Game and displays the approprite text: pause img, text, button


def pausegame():
    global GameisResumed, pauseimage, image
    if GameisResumed is True:
        pauseimage = PhotoImage(file='gamepause.png')
        GameisResumed = False
        showbuttons()
        strVar.set(Continue)
        canvas.create_image(275, 200, anchor=CENTER,
                            image=pauseimage, tag='pausing')
        canvas.create_text(270, 325, text='GAME PAUSED', font='Arcade 25 bold',
                           fill='red', tag='labelpause')

# Continues Game and displays the approprite text: Continue game
# countdown, button


def continuegame():
    global GameisResumed, txt3, strVar, pause, Continue, img2, img3
    GameisResumed = True
    hidebuttons()
    strVar.set(pause)
    resuminggame()

# hides buttons because game is resumed


def hidebuttons():

    Button9.destroy()
    Button10.destroy()
    ButtonA.destroy()
    ButtonB.destroy()
    return

# shows buttons because game is paused


def showbuttons():
    global Button9, Button10, ButtonA, ButtonB
    Button9 = Button(window, text="MAIN MENU", width=10, height=2,
                     highlightbackground='black',
                     command=lambda: GoToMainMenu())
    Button9.place(x=35, y=170)
    Button10 = Button(window, text="SAVE GAME", width=10, height=2,
                      highlightbackground='black',
                      command=lambda: savegamefunc())
    Button10.place(x=35, y=270)
    ButtonA = Button(window, text="LOAD GAME", width=10, height=2,
                     highlightbackground='black',
                     command=lambda: loadgamefunc())
    ButtonA.place(x=35, y=370)
    ButtonB = Button(window, text="CONTROLS", width=10, height=2,
                     highlightbackground='black',
                     command=lambda: controlcustomization())
    ButtonB.place(x=35, y=470)


# displays information on game such as score, level and pause/continue button
def labels():
    global Button8, score, scoreText, txt, level
    global levellabel, pause, leveltext, txt2, FirstPlay
    global strVar, levelText, Levelvar
    strVar = StringVar()
    strVar.set(pause)
    scoreText = Label(
        window,
        fg="white",
        textvariable=ScoreVar,
        font="Arcade 20 italic bold",
        bg='black')
    scoreText.place(x=55, y=15)
    levelText = Label(
        window,
        textvariable=Levelvar,
        fg="white",
        font="Arcade 20 bold",
        bg='black')
    levelText.place(x=55, y=55)
    Button8 = Button(window, textvariable=strVar, width=10, height=2,
                     highlightbackground='black',
                     command=lambda: ContinueorPauseGame())
    Button8.place(x=35, y=90)

# decides if to puase or continue game


def ContinueorPauseGame():
    global GameisResumed

    if GameisResumed is True:
        pausegame()
    else:
        continuegame()

# username entry page to save it to file with the score


def username():

    global window3, canvas3, ans, name, label1, button7, frame3
    window3 = Toplevel()
    window3.resizable(False, False)
    window3.title('Info')
    window3.config(bg='grey')
    canvas3 = Canvas(window3, width=width, height=height)
    canvas3.create_image(
        width / 2,
        height / 2,
        anchor=CENTER,
        image=textureimage,
        tag='texture')
    canvas3.place(x=0, y=0)
    window3 = setWindowDimension5(width, height)
    frame3 = LabelFrame(
        canvas3,
        text='  Enter Your Name: ',
        padx=20,
        pady=30,
        font='Arcade 20 bold',
        bg='grey',
        bd=4,
        fg='black')
    frame3.place(x=125, y=10)

    name = Entry(frame3)
    name.pack(padx=20, pady=30)

    button7 = Button(frame3, text='ENTER', relief=FLAT, height=2, width=20,
                     highlightbackground='black', command=checkname)
    button7.pack(padx=30, pady=20)
    buttonB = Button(frame3, text='BACK', relief=FLAT, height=2, width=10,
                     highlightbackground='black', command=closewindow3)
    buttonB.pack(padx=30, pady=25)

    window3.mainloop()

# to check if name is empty, if not you are all set


def checkname():
    global name, errortext, PlayerName
    if len(name.get()) == 0:
        textABC3 = "You can't have your name empty! try again."
        errortext = canvas3.create_text(280, 400, fill="red",
                                        font="Arcade 20 bold",
                                        text=textABC3,
                                        tag='error')
        canvas3.update()
        time.sleep(2)
        canvas3.delete('error')
    else:
        PlayerName = name.get()
        window3.destroy()
        loadingscreen2()

# function for the main game


def startgame():
    global window, Currentlevelsaved, canvas, snake
    global snakeSize, level, scoreText, direction, strVar
    global pause, Continue, GameisResumed, start, GameReady, currentlevel
    global SpeedofGame, ScoreVar, Levelvar, ClockOne, ClockTwo
    global gameOver, SpeedofGame, Directionsaved, score
    pause = "Pause"
    Continue = "Continue"
    gameOver = False
    ClockOne = False
    ClockTwo = False
    GameisResumed = True
    SpeedofGame = 120
    window = Toplevel()
    window.resizable(False, False)
    window.title('Snake Game')
    window.config(bg='grey')
    window = setWindowDimensionforgame()
    canvas = Canvas(window, bg='white', width=width, height=height)
    grass = PhotoImage(file="grass.png")
    canvas.create_image(375, 225, image=grass)
    canvas.pack()
    canvas.bind('p', bosskey)
    canvas.bind('o', cheat)
    snake = []
    snakeSize = 15
    snake.append(canvas.create_rectangle(snakeSize, snakeSize, snakeSize * 2,
                                         snakeSize * 2, fill="orange"))
    if GameReady:
        canvas.coords(snake[0], HeadPossaved[0], HeadPossaved[1],
                      HeadPossaved[2], HeadPossaved[3])
    if GameReady:
        score = Scoresaved
    else:
        score = 0

    if GameReady:
        growth = int(score / 5)
        print(growth)
        for i in range(growth):
            growSnake()
    if GameReady:
        currentlevel = Currentlevelsaved
    else:
        currentlevel = 1
    txt2 = "LEVEL: " + str(currentlevel)
    Levelvar = StringVar()
    Levelvar.set(txt2)
    txt = "SCORE:" + str(score)
    ScoreVar = StringVar()
    ScoreVar.set(txt)

    canvas.bind("<Left>", leftKey)
    canvas.bind("<Right>", rightKey)
    canvas.bind("<Up>", upKey)
    canvas.bind("<Down>", downKey)
    canvas.focus_set()

    if GameReady:
        direction = Directionsaved
    else:
        direction = "right"

    labels()
    placeFood()
    moveSnake()

    window.mainloop()

# Function to make the snake body follow its head with growing


def growSnake():
    global score, level, currentlevel, canvas, txt2, txt
    lastElement = len(snake) - 1
    lastElementPos = canvas.coords(snake[lastElement])
    snake.append(
        canvas.create_rectangle(
            0,
            0,
            snakeSize,
            snakeSize,
            fill="black"))

    if (direction == "left"):
        canvas.coords(snake[lastElement + 1],
                      lastElementPos[0] + snakeSize, lastElementPos[1],
                      lastElementPos[2] + snakeSize, lastElementPos[3])

    elif (direction == "right"):
        canvas.coords(snake[lastElement + 1],
                      lastElementPos[0] - snakeSize, lastElementPos[1],
                      lastElementPos[2] - snakeSize, lastElementPos[3])

    elif (direction == "up"):
        canvas.coords(snake[lastElement + 1], lastElementPos[0],
                      lastElementPos[1] + snakeSize,
                      lastElementPos[2], lastElementPos[3] + snakeSize)

    else:
        canvas.coords(snake[lastElement + 1], lastElementPos[0],
                      lastElementPos[1] - snakeSize, lastElementPos[2],
                      lastElementPos[3] - snakeSize)

# to move food around if snake head collides with food


def moveFood():
    global food, foodX, foodY, GameReady
    canvas.move(food, (foodX * (-1)), (foodY * (-1)))
    foodX = random.randint(0, width - snakeSize)
    foodY = random.randint(0, height - snakeSize)
    canvas.move(food, foodX, foodY)

# to check if elements are overlapping such as snake head, food, walls,
# snake body.. etc..


def overlapping(a, b):
    if a[0] < b[2] and a[2] > b[0] and a[1] < b[3] and a[3] > b[1]:
        return True
    return False

# this function includes levels settings, and sets the fundementals for
# overlapping.


def moveSnake():
    global canvas, strVar, pause, positions, Hardstop
    global currentlevel, GameReady, score, ScoreVar, Levelvar
    global sHeadPos, foodPos, ClockOne, ClockTwo, SpeedofGame
    global GameisResumed, GameOver
    Hardstop = False
    canvas.pack(side=RIGHT)
    if GameReady:
        pausegame()
    positions = []
    while True:
        if GameisResumed:
            positions.append(canvas.coords(snake[0]))
            if positions[0][0] < 0:
                if currentlevel == "MAX":
                    gameoverfunc()
                    Hardstop = True
                else:
                    canvas.coords(
                        snake[0],
                        width,
                        positions[0][1],
                        width - snakeSize,
                        positions[0][3])
            if Hardstop:
                break
            elif positions[0][2] > width:
                if currentlevel == "MAX":
                    gameoverfunc()
                    Hardstop = True
                else:
                    canvas.coords(
                        snake[0],
                        0 - snakeSize,
                        positions[0][1],
                        0,
                        positions[0][3])
            if Hardstop:
                break
            elif positions[0][3] > height:
                if currentlevel == "MAX" or currentlevel == 6:
                    GameOver()
                    Hardstop = True
                else:
                    canvas.coords(
                        snake[0],
                        positions[0][0],
                        0 - snakeSize,
                        positions[0][2],
                        0)
            if Hardstop:
                break
            elif positions[0][1] < 0:
                if currentlevel == "MAX" or currentlevel == 6:
                    gameoverfunc()
                    Hardstop = True
                else:
                    canvas.coords(
                        snake[0],
                        positions[0][0],
                        height,
                        positions[0][2],
                        height - snakeSize)
            if Hardstop:
                break
            positions.clear()
            positions.append(canvas.coords(snake[0]))
            if direction == "left":
                canvas.move(snake[0], -snakeSize, 0)
            elif direction == "right":
                canvas.move(snake[0], snakeSize, 0)
            elif direction == "up":
                canvas.move(snake[0], 0, -snakeSize)
            elif direction == "down":
                canvas.move(snake[0], 0, snakeSize)
            sHeadPos = canvas.coords(snake[0])
            foodPos = canvas.coords(food)
            if overlapping(sHeadPos, foodPos):
                moveFood()
                growSnake()
                score += 5
                txt = "SCORE:" + str(score)
                ScoreVar.set(txt)
            if GameReady is False:
                for i in range(1, len(snake)):
                    if overlapping(sHeadPos, canvas.coords(snake[i])):
                        gameoverfunc()
                        Hardstop = True
            if Hardstop:
                break
            for i in range(1, len(snake)):
                positions.append(canvas.coords(snake[i]))
            if GameReady is False:
                for i in range(len(snake) - 1):
                    canvas.coords(snake[i + 1],
                                  positions[i][0], positions[i][1],
                                  positions[i][2], positions[i][3])

            if gameOver is False:
                window.after(SpeedofGame, moveSnake)
                if (20 > score > 10):
                    currentlevel = 2
                    txt2 = "LEVEL: " + str(currentlevel)
                    Levelvar.set(txt2)
                    SpeedofGame = 140
                elif (30 > score > 20):
                    currentlevel = 3
                    txt2 = "LEVEL: " + str(currentlevel)
                    Levelvar.set(txt2)
                    SpeedofGame = 110
                elif (50 > score > 40):
                    currentlevel = 4
                    txt2 = "Level: " + str(currentlevel)
                    Levelvar.set(txt2)
                    SpeedofGame = 190
                elif (80 > score > 60):
                    currentlevel = 5
                    txt2 = "LEVEL: " + str(currentlevel)
                    Levelvar.set(txt2)
                    SpeedofGame = 80
                elif (180 > score > 140) and ClockOne is False:
                    currentlevel = 6
                    txt2 = "LEVEL: " + str(currentlevel)
                    Levelvar.set(txt2)
                    SpeedofGame = 60
                    ClockOne = True
                    if GameReady is False:
                        canvas.create_text(280, 200,
                                           fill="red", font="Arcade 30 bold",
                                           text="Top & Down Walls Are CLOSED",
                                           underline=1, tag="note1")
                        canvas.update()
                        time.sleep(2)
                        canvas.delete("note1")
                        canvas.update()
                elif (score > 240) and ClockTwo is False:
                    currentlevel = "MAX"
                    txt2 = "LEVEL: " + str(currentlevel)
                    Levelvar.set(txt2)
                    SpeedofGame = 60
                    ClockTwo = True
                    if GameReady is False:
                        canvas.create_text(280, 200, fill="red",
                                           font="Times 30 bold",
                                           text="All Walls Are CLOSED!",
                                           underline=1, tag="note2")
                        canvas.update()
                        time.sleep(2)
                        canvas.delete("note2")
                        canvas.update()

                else:
                    pass

            GameReady = False
            break

        else:
            window.update()

# place food randomly or from previous run if game loaded


def placeFood():
    global food, foodX, foodY, GameReady, FoodXsaved, FoodYsaved
    food = canvas.create_rectangle(0, 0, snakeSize, snakeSize, fill="brown")
    if GameReady:
        foodX = FoodXsaved
        foodY = FoodYsaved
    else:
        foodX = random.randint(0, width - snakeSize)
        foodY = random.randint(0, height - snakeSize)
    canvas.move(food, foodX, foodY)


def leftKey(event):
    global direction
    direction = "left"


def rightKey(event):
    global direction
    direction = "right"


def upKey(event):
    global direction
    direction = "up"


def downKey(event):
    global direction
    direction = "down"


def setWindowDimension(w, h):

    ws = window2.winfo_screenwidth()  # computer screen size
    hs = window2.winfo_screenheight()
    x = (ws / 2) - (w / 2)  # calculate center
    y = (hs / 2) - (h / 2)
    window2.geometry('%dx%d+%d+%d' % (w, h, x, y))  # window size
    return window2


def setWindowDimension2(w, h):

    ws = window5.winfo_screenwidth()  # computer screen size
    hs = window5.winfo_screenheight()
    x = (ws / 2) - (w / 2)  # calculate center
    y = (hs / 2) - (h / 2)
    window5.geometry('%dx%d+%d+%d' % (w, h, x, y))  # window size
    return window5


def setWindowDimension3(w, h):

    ws = window10.winfo_screenwidth()  # computer screen size
    hs = window10.winfo_screenheight()
    x = (ws / 2) - (w / 2)  # calculate center
    y = (hs / 2) - (h / 2)
    window10.geometry('%dx%d+%d+%d' % (w, h, x, y))  # window size
    return window10


def setWindowDimension4(w, h):

    ws = window4.winfo_screenwidth()  # computer screen size
    hs = window4.winfo_screenheight()
    x = (ws / 2) - (w / 2)  # calculate center
    y = (hs / 2) - (h / 2)
    window4.geometry('%dx%d+%d+%d' % (w, h, x, y))  # window size
    return window4


def setWindowDimension5(w, h):

    ws = window3.winfo_screenwidth()  # computer screen size
    hs = window3.winfo_screenheight()
    x = (ws / 2) - (w / 2)  # calculate center
    y = (hs / 2) - (h / 2)
    window3.geometry('%dx%d+%d+%d' % (w, h, x, y))  # window size
    return window3


def setWindowDimensionforgame():
    window.geometry("750x550")  # window size
    return window


def restartgame():
    window.destroy()
    StartFresh()


def closemainmenu():
    tkinter.messagebox.showinfo('Thanks', 'Thank You For Playing!!!')
    window2.destroy()


def closewindow():
    time.sleep(2)
    window5.destroy()
    mainmenu()


def closewindow2():
    time.sleep(2)
    window10.destroy()
    StartFresh()


def closewindow3():
    window3.destroy()


def closewindow4():
    window4.destroy()

# Main Menu which has the buttons displayed in all of it


def mainmenu():
    global window2, canvas2, frame, width, gameOver
    global height, textureimage, GameReady
    GameReady = False
    gameOver = False
    window2 = Tk()
    textureimage = PhotoImage(file='texture.png')
    window2.resizable(False, False)
    window2.title('Main Menu')
    canvas2 = Canvas(window2, width=width, height=height)
    canvas2.place(x=0, y=0)
    canvas2.create_image(
        width / 2,
        height / 2,
        anchor=CENTER,
        image=textureimage,
        tag='texture')
    window2 = setWindowDimension(width, height)
    frame = LabelFrame(canvas2, text='SNAKE GAME', padx=20, pady=20,
                       font='Times 70 bold', bg='grey', bd=4, fg='darkred')
    frame.place(x=30, y=10)

    button = Button(frame, text='START NEW', relief=FLAT, height=2,
                    width=40, highlightbackground='black',
                    bg='grey', command=username)
    button.pack()

    buttonC = Button(frame, text='CONTINUE', relief=FLAT, height=2,
                     width=40, highlightbackground='black',
                     bg='grey', command=PreviousRun)
    buttonC.pack()

    button3 = Button(frame, text='LEADERBOARD', relief=FLAT,
                     height=2, width=40, highlightbackground='black',
                     command=leaderboard)
    button3.pack()

    button5 = Button(frame, text='QUIT GAME', relief=FLAT, height=2,
                     width=40, highlightbackground='black',
                     command=closemainmenu)
    button5.pack()

    window2.mainloop()


# starting point
FirstPlay = True
GameisResumed = True  # sets all the condtions before the game
GameReady = False
loadingscreen()
